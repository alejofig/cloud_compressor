/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 926.0, "minX": 0.0, "maxY": 35550.0, "series": [{"data": [[0.0, 926.0], [0.1, 941.0], [0.2, 951.0], [0.3, 975.0], [0.4, 982.0], [0.5, 985.0], [0.6, 987.0], [0.7, 990.0], [0.8, 991.0], [0.9, 995.0], [1.0, 997.0], [1.1, 999.0], [1.2, 1000.0], [1.3, 1003.0], [1.4, 1005.0], [1.5, 1008.0], [1.6, 1010.0], [1.7, 1011.0], [1.8, 1013.0], [1.9, 1018.0], [2.0, 1019.0], [2.1, 1021.0], [2.2, 1024.0], [2.3, 1024.0], [2.4, 1026.0], [2.5, 1026.0], [2.6, 1027.0], [2.7, 1027.0], [2.8, 1028.0], [2.9, 1031.0], [3.0, 1031.0], [3.1, 1033.0], [3.2, 1034.0], [3.3, 1037.0], [3.4, 1038.0], [3.5, 1038.0], [3.6, 1039.0], [3.7, 1040.0], [3.8, 1041.0], [3.9, 1042.0], [4.0, 1043.0], [4.1, 1043.0], [4.2, 1044.0], [4.3, 1044.0], [4.4, 1045.0], [4.5, 1046.0], [4.6, 1047.0], [4.7, 1048.0], [4.8, 1050.0], [4.9, 1052.0], [5.0, 1053.0], [5.1, 1054.0], [5.2, 1056.0], [5.3, 1057.0], [5.4, 1060.0], [5.5, 1060.0], [5.6, 1062.0], [5.7, 1063.0], [5.8, 1064.0], [5.9, 1065.0], [6.0, 1066.0], [6.1, 1067.0], [6.2, 1067.0], [6.3, 1070.0], [6.4, 1070.0], [6.5, 1071.0], [6.6, 1072.0], [6.7, 1072.0], [6.8, 1073.0], [6.9, 1075.0], [7.0, 1076.0], [7.1, 1076.0], [7.2, 1077.0], [7.3, 1078.0], [7.4, 1079.0], [7.5, 1081.0], [7.6, 1082.0], [7.7, 1082.0], [7.8, 1083.0], [7.9, 1084.0], [8.0, 1085.0], [8.1, 1087.0], [8.2, 1087.0], [8.3, 1088.0], [8.4, 1089.0], [8.5, 1090.0], [8.6, 1091.0], [8.7, 1093.0], [8.8, 1093.0], [8.9, 1094.0], [9.0, 1096.0], [9.1, 1098.0], [9.2, 1101.0], [9.3, 1101.0], [9.4, 1102.0], [9.5, 1103.0], [9.6, 1105.0], [9.7, 1106.0], [9.8, 1107.0], [9.9, 1110.0], [10.0, 1110.0], [10.1, 1112.0], [10.2, 1113.0], [10.3, 1114.0], [10.4, 1114.0], [10.5, 1117.0], [10.6, 1117.0], [10.7, 1118.0], [10.8, 1119.0], [10.9, 1120.0], [11.0, 1122.0], [11.1, 1122.0], [11.2, 1125.0], [11.3, 1126.0], [11.4, 1126.0], [11.5, 1127.0], [11.6, 1128.0], [11.7, 1129.0], [11.8, 1133.0], [11.9, 1134.0], [12.0, 1136.0], [12.1, 1137.0], [12.2, 1138.0], [12.3, 1141.0], [12.4, 1141.0], [12.5, 1142.0], [12.6, 1143.0], [12.7, 1144.0], [12.8, 1146.0], [12.9, 1147.0], [13.0, 1147.0], [13.1, 1148.0], [13.2, 1148.0], [13.3, 1151.0], [13.4, 1152.0], [13.5, 1152.0], [13.6, 1154.0], [13.7, 1155.0], [13.8, 1156.0], [13.9, 1159.0], [14.0, 1159.0], [14.1, 1161.0], [14.2, 1161.0], [14.3, 1162.0], [14.4, 1163.0], [14.5, 1165.0], [14.6, 1167.0], [14.7, 1168.0], [14.8, 1169.0], [14.9, 1170.0], [15.0, 1172.0], [15.1, 1173.0], [15.2, 1174.0], [15.3, 1174.0], [15.4, 1175.0], [15.5, 1176.0], [15.6, 1177.0], [15.7, 1179.0], [15.8, 1181.0], [15.9, 1185.0], [16.0, 1185.0], [16.1, 1188.0], [16.2, 1190.0], [16.3, 1190.0], [16.4, 1191.0], [16.5, 1192.0], [16.6, 1193.0], [16.7, 1193.0], [16.8, 1194.0], [16.9, 1195.0], [17.0, 1198.0], [17.1, 1199.0], [17.2, 1200.0], [17.3, 1203.0], [17.4, 1203.0], [17.5, 1204.0], [17.6, 1204.0], [17.7, 1205.0], [17.8, 1206.0], [17.9, 1207.0], [18.0, 1208.0], [18.1, 1210.0], [18.2, 1210.0], [18.3, 1214.0], [18.4, 1215.0], [18.5, 1216.0], [18.6, 1222.0], [18.7, 1222.0], [18.8, 1224.0], [18.9, 1225.0], [19.0, 1228.0], [19.1, 1229.0], [19.2, 1230.0], [19.3, 1232.0], [19.4, 1235.0], [19.5, 1237.0], [19.6, 1238.0], [19.7, 1241.0], [19.8, 1243.0], [19.9, 1243.0], [20.0, 1243.0], [20.1, 1246.0], [20.2, 1248.0], [20.3, 1250.0], [20.4, 1252.0], [20.5, 1252.0], [20.6, 1255.0], [20.7, 1257.0], [20.8, 1259.0], [20.9, 1261.0], [21.0, 1263.0], [21.1, 1265.0], [21.2, 1266.0], [21.3, 1266.0], [21.4, 1267.0], [21.5, 1271.0], [21.6, 1272.0], [21.7, 1274.0], [21.8, 1275.0], [21.9, 1275.0], [22.0, 1276.0], [22.1, 1279.0], [22.2, 1282.0], [22.3, 1283.0], [22.4, 1286.0], [22.5, 1286.0], [22.6, 1287.0], [22.7, 1288.0], [22.8, 1288.0], [22.9, 1289.0], [23.0, 1291.0], [23.1, 1291.0], [23.2, 1293.0], [23.3, 1294.0], [23.4, 1294.0], [23.5, 1299.0], [23.6, 1299.0], [23.7, 1301.0], [23.8, 1302.0], [23.9, 1302.0], [24.0, 1304.0], [24.1, 1305.0], [24.2, 1306.0], [24.3, 1309.0], [24.4, 1310.0], [24.5, 1311.0], [24.6, 1312.0], [24.7, 1312.0], [24.8, 1314.0], [24.9, 1314.0], [25.0, 1315.0], [25.1, 1315.0], [25.2, 1319.0], [25.3, 1320.0], [25.4, 1322.0], [25.5, 1323.0], [25.6, 1324.0], [25.7, 1324.0], [25.8, 1326.0], [25.9, 1327.0], [26.0, 1330.0], [26.1, 1332.0], [26.2, 1332.0], [26.3, 1333.0], [26.4, 1336.0], [26.5, 1337.0], [26.6, 1339.0], [26.7, 1341.0], [26.8, 1342.0], [26.9, 1344.0], [27.0, 1344.0], [27.1, 1345.0], [27.2, 1346.0], [27.3, 1346.0], [27.4, 1347.0], [27.5, 1348.0], [27.6, 1349.0], [27.7, 1349.0], [27.8, 1350.0], [27.9, 1351.0], [28.0, 1352.0], [28.1, 1352.0], [28.2, 1353.0], [28.3, 1354.0], [28.4, 1355.0], [28.5, 1359.0], [28.6, 1361.0], [28.7, 1363.0], [28.8, 1364.0], [28.9, 1366.0], [29.0, 1369.0], [29.1, 1369.0], [29.2, 1371.0], [29.3, 1373.0], [29.4, 1374.0], [29.5, 1375.0], [29.6, 1375.0], [29.7, 1377.0], [29.8, 1377.0], [29.9, 1380.0], [30.0, 1380.0], [30.1, 1381.0], [30.2, 1383.0], [30.3, 1384.0], [30.4, 1385.0], [30.5, 1388.0], [30.6, 1390.0], [30.7, 1391.0], [30.8, 1391.0], [30.9, 1393.0], [31.0, 1394.0], [31.1, 1395.0], [31.2, 1397.0], [31.3, 1398.0], [31.4, 1398.0], [31.5, 1398.0], [31.6, 1405.0], [31.7, 1406.0], [31.8, 1407.0], [31.9, 1408.0], [32.0, 1410.0], [32.1, 1410.0], [32.2, 1415.0], [32.3, 1416.0], [32.4, 1417.0], [32.5, 1420.0], [32.6, 1423.0], [32.7, 1424.0], [32.8, 1425.0], [32.9, 1426.0], [33.0, 1428.0], [33.1, 1429.0], [33.2, 1429.0], [33.3, 1430.0], [33.4, 1433.0], [33.5, 1435.0], [33.6, 1436.0], [33.7, 1437.0], [33.8, 1439.0], [33.9, 1440.0], [34.0, 1441.0], [34.1, 1441.0], [34.2, 1444.0], [34.3, 1445.0], [34.4, 1445.0], [34.5, 1447.0], [34.6, 1448.0], [34.7, 1450.0], [34.8, 1450.0], [34.9, 1452.0], [35.0, 1457.0], [35.1, 1457.0], [35.2, 1463.0], [35.3, 1464.0], [35.4, 1464.0], [35.5, 1465.0], [35.6, 1466.0], [35.7, 1468.0], [35.8, 1468.0], [35.9, 1470.0], [36.0, 1472.0], [36.1, 1474.0], [36.2, 1474.0], [36.3, 1475.0], [36.4, 1477.0], [36.5, 1478.0], [36.6, 1479.0], [36.7, 1481.0], [36.8, 1484.0], [36.9, 1486.0], [37.0, 1489.0], [37.1, 1491.0], [37.2, 1492.0], [37.3, 1493.0], [37.4, 1495.0], [37.5, 1495.0], [37.6, 1496.0], [37.7, 1496.0], [37.8, 1499.0], [37.9, 1500.0], [38.0, 1504.0], [38.1, 1506.0], [38.2, 1508.0], [38.3, 1509.0], [38.4, 1512.0], [38.5, 1512.0], [38.6, 1514.0], [38.7, 1515.0], [38.8, 1517.0], [38.9, 1518.0], [39.0, 1519.0], [39.1, 1521.0], [39.2, 1522.0], [39.3, 1522.0], [39.4, 1524.0], [39.5, 1525.0], [39.6, 1527.0], [39.7, 1528.0], [39.8, 1528.0], [39.9, 1533.0], [40.0, 1534.0], [40.1, 1537.0], [40.2, 1538.0], [40.3, 1540.0], [40.4, 1544.0], [40.5, 1549.0], [40.6, 1550.0], [40.7, 1550.0], [40.8, 1550.0], [40.9, 1552.0], [41.0, 1554.0], [41.1, 1555.0], [41.2, 1556.0], [41.3, 1558.0], [41.4, 1559.0], [41.5, 1561.0], [41.6, 1563.0], [41.7, 1565.0], [41.8, 1568.0], [41.9, 1569.0], [42.0, 1570.0], [42.1, 1571.0], [42.2, 1573.0], [42.3, 1574.0], [42.4, 1576.0], [42.5, 1578.0], [42.6, 1579.0], [42.7, 1581.0], [42.8, 1586.0], [42.9, 1586.0], [43.0, 1586.0], [43.1, 1587.0], [43.2, 1588.0], [43.3, 1592.0], [43.4, 1594.0], [43.5, 1595.0], [43.6, 1596.0], [43.7, 1597.0], [43.8, 1600.0], [43.9, 1604.0], [44.0, 1606.0], [44.1, 1609.0], [44.2, 1610.0], [44.3, 1612.0], [44.4, 1614.0], [44.5, 1615.0], [44.6, 1617.0], [44.7, 1618.0], [44.8, 1621.0], [44.9, 1622.0], [45.0, 1623.0], [45.1, 1625.0], [45.2, 1627.0], [45.3, 1628.0], [45.4, 1629.0], [45.5, 1632.0], [45.6, 1633.0], [45.7, 1634.0], [45.8, 1635.0], [45.9, 1640.0], [46.0, 1640.0], [46.1, 1643.0], [46.2, 1646.0], [46.3, 1648.0], [46.4, 1653.0], [46.5, 1654.0], [46.6, 1654.0], [46.7, 1656.0], [46.8, 1657.0], [46.9, 1661.0], [47.0, 1663.0], [47.1, 1664.0], [47.2, 1664.0], [47.3, 1665.0], [47.4, 1668.0], [47.5, 1671.0], [47.6, 1675.0], [47.7, 1676.0], [47.8, 1682.0], [47.9, 1686.0], [48.0, 1687.0], [48.1, 1691.0], [48.2, 1692.0], [48.3, 1694.0], [48.4, 1699.0], [48.5, 1706.0], [48.6, 1711.0], [48.7, 1714.0], [48.8, 1717.0], [48.9, 1718.0], [49.0, 1719.0], [49.1, 1720.0], [49.2, 1724.0], [49.3, 1726.0], [49.4, 1728.0], [49.5, 1729.0], [49.6, 1730.0], [49.7, 1730.0], [49.8, 1731.0], [49.9, 1734.0], [50.0, 1736.0], [50.1, 1740.0], [50.2, 1744.0], [50.3, 1751.0], [50.4, 1759.0], [50.5, 1761.0], [50.6, 1762.0], [50.7, 1766.0], [50.8, 1771.0], [50.9, 1773.0], [51.0, 1778.0], [51.1, 1787.0], [51.2, 1789.0], [51.3, 1790.0], [51.4, 1796.0], [51.5, 1799.0], [51.6, 1802.0], [51.7, 1805.0], [51.8, 1805.0], [51.9, 1808.0], [52.0, 1811.0], [52.1, 1813.0], [52.2, 1815.0], [52.3, 1816.0], [52.4, 1817.0], [52.5, 1818.0], [52.6, 1821.0], [52.7, 1822.0], [52.8, 1827.0], [52.9, 1829.0], [53.0, 1831.0], [53.1, 1835.0], [53.2, 1837.0], [53.3, 1840.0], [53.4, 1845.0], [53.5, 1847.0], [53.6, 1851.0], [53.7, 1853.0], [53.8, 1855.0], [53.9, 1855.0], [54.0, 1858.0], [54.1, 1860.0], [54.2, 1861.0], [54.3, 1862.0], [54.4, 1863.0], [54.5, 1866.0], [54.6, 1870.0], [54.7, 1870.0], [54.8, 1874.0], [54.9, 1877.0], [55.0, 1880.0], [55.1, 1882.0], [55.2, 1883.0], [55.3, 1889.0], [55.4, 1890.0], [55.5, 1892.0], [55.6, 1894.0], [55.7, 1895.0], [55.8, 1897.0], [55.9, 1898.0], [56.0, 1903.0], [56.1, 1912.0], [56.2, 1914.0], [56.3, 1915.0], [56.4, 1919.0], [56.5, 1922.0], [56.6, 1930.0], [56.7, 1931.0], [56.8, 1935.0], [56.9, 1936.0], [57.0, 1937.0], [57.1, 1940.0], [57.2, 1946.0], [57.3, 1951.0], [57.4, 1953.0], [57.5, 1954.0], [57.6, 1956.0], [57.7, 1960.0], [57.8, 1966.0], [57.9, 1966.0], [58.0, 1970.0], [58.1, 1974.0], [58.2, 1974.0], [58.3, 1976.0], [58.4, 1981.0], [58.5, 1984.0], [58.6, 1986.0], [58.7, 1987.0], [58.8, 1989.0], [58.9, 1997.0], [59.0, 1999.0], [59.1, 2004.0], [59.2, 2007.0], [59.3, 2010.0], [59.4, 2016.0], [59.5, 2021.0], [59.6, 2023.0], [59.7, 2024.0], [59.8, 2027.0], [59.9, 2029.0], [60.0, 2032.0], [60.1, 2038.0], [60.2, 2039.0], [60.3, 2043.0], [60.4, 2047.0], [60.5, 2049.0], [60.6, 2056.0], [60.7, 2058.0], [60.8, 2059.0], [60.9, 2063.0], [61.0, 2065.0], [61.1, 2068.0], [61.2, 2071.0], [61.3, 2072.0], [61.4, 2076.0], [61.5, 2082.0], [61.6, 2084.0], [61.7, 2086.0], [61.8, 2092.0], [61.9, 2099.0], [62.0, 2102.0], [62.1, 2103.0], [62.2, 2106.0], [62.3, 2109.0], [62.4, 2115.0], [62.5, 2121.0], [62.6, 2122.0], [62.7, 2123.0], [62.8, 2125.0], [62.9, 2128.0], [63.0, 2129.0], [63.1, 2133.0], [63.2, 2137.0], [63.3, 2147.0], [63.4, 2153.0], [63.5, 2157.0], [63.6, 2158.0], [63.7, 2160.0], [63.8, 2166.0], [63.9, 2173.0], [64.0, 2173.0], [64.1, 2180.0], [64.2, 2188.0], [64.3, 2190.0], [64.4, 2193.0], [64.5, 2198.0], [64.6, 2204.0], [64.7, 2205.0], [64.8, 2206.0], [64.9, 2212.0], [65.0, 2213.0], [65.1, 2215.0], [65.2, 2217.0], [65.3, 2219.0], [65.4, 2227.0], [65.5, 2232.0], [65.6, 2232.0], [65.7, 2241.0], [65.8, 2242.0], [65.9, 2248.0], [66.0, 2250.0], [66.1, 2251.0], [66.2, 2254.0], [66.3, 2256.0], [66.4, 2259.0], [66.5, 2270.0], [66.6, 2271.0], [66.7, 2276.0], [66.8, 2280.0], [66.9, 2282.0], [67.0, 2289.0], [67.1, 2289.0], [67.2, 2300.0], [67.3, 2302.0], [67.4, 2306.0], [67.5, 2312.0], [67.6, 2317.0], [67.7, 2319.0], [67.8, 2326.0], [67.9, 2331.0], [68.0, 2335.0], [68.1, 2337.0], [68.2, 2343.0], [68.3, 2348.0], [68.4, 2350.0], [68.5, 2356.0], [68.6, 2357.0], [68.7, 2366.0], [68.8, 2382.0], [68.9, 2387.0], [69.0, 2389.0], [69.1, 2400.0], [69.2, 2403.0], [69.3, 2407.0], [69.4, 2408.0], [69.5, 2409.0], [69.6, 2413.0], [69.7, 2422.0], [69.8, 2434.0], [69.9, 2437.0], [70.0, 2440.0], [70.1, 2448.0], [70.2, 2454.0], [70.3, 2456.0], [70.4, 2467.0], [70.5, 2470.0], [70.6, 2477.0], [70.7, 2483.0], [70.8, 2491.0], [70.9, 2503.0], [71.0, 2505.0], [71.1, 2507.0], [71.2, 2513.0], [71.3, 2514.0], [71.4, 2522.0], [71.5, 2526.0], [71.6, 2531.0], [71.7, 2538.0], [71.8, 2543.0], [71.9, 2557.0], [72.0, 2562.0], [72.1, 2568.0], [72.2, 2573.0], [72.3, 2577.0], [72.4, 2585.0], [72.5, 2588.0], [72.6, 2589.0], [72.7, 2596.0], [72.8, 2598.0], [72.9, 2608.0], [73.0, 2613.0], [73.1, 2624.0], [73.2, 2635.0], [73.3, 2640.0], [73.4, 2643.0], [73.5, 2645.0], [73.6, 2649.0], [73.7, 2659.0], [73.8, 2664.0], [73.9, 2672.0], [74.0, 2681.0], [74.1, 2689.0], [74.2, 2693.0], [74.3, 2698.0], [74.4, 2703.0], [74.5, 2708.0], [74.6, 2711.0], [74.7, 2716.0], [74.8, 2735.0], [74.9, 2741.0], [75.0, 2757.0], [75.1, 2759.0], [75.2, 2769.0], [75.3, 2782.0], [75.4, 2784.0], [75.5, 2785.0], [75.6, 2795.0], [75.7, 2813.0], [75.8, 2834.0], [75.9, 2838.0], [76.0, 2851.0], [76.1, 2864.0], [76.2, 2869.0], [76.3, 2876.0], [76.4, 2884.0], [76.5, 2887.0], [76.6, 2896.0], [76.7, 2909.0], [76.8, 2912.0], [76.9, 2921.0], [77.0, 2928.0], [77.1, 2945.0], [77.2, 2949.0], [77.3, 2950.0], [77.4, 2963.0], [77.5, 2964.0], [77.6, 2968.0], [77.7, 2981.0], [77.8, 2992.0], [77.9, 3012.0], [78.0, 3014.0], [78.1, 3022.0], [78.2, 3027.0], [78.3, 3032.0], [78.4, 3048.0], [78.5, 3050.0], [78.6, 3054.0], [78.7, 3061.0], [78.8, 3068.0], [78.9, 3082.0], [79.0, 3095.0], [79.1, 3105.0], [79.2, 3116.0], [79.3, 3123.0], [79.4, 3128.0], [79.5, 3137.0], [79.6, 3182.0], [79.7, 3195.0], [79.8, 3203.0], [79.9, 3207.0], [80.0, 3221.0], [80.1, 3231.0], [80.2, 3245.0], [80.3, 3278.0], [80.4, 3291.0], [80.5, 3296.0], [80.6, 3299.0], [80.7, 3301.0], [80.8, 3317.0], [80.9, 3322.0], [81.0, 3326.0], [81.1, 3340.0], [81.2, 3348.0], [81.3, 3367.0], [81.4, 3371.0], [81.5, 3393.0], [81.6, 3402.0], [81.7, 3408.0], [81.8, 3415.0], [81.9, 3418.0], [82.0, 3428.0], [82.1, 3430.0], [82.2, 3438.0], [82.3, 3446.0], [82.4, 3449.0], [82.5, 3457.0], [82.6, 3471.0], [82.7, 3473.0], [82.8, 3476.0], [82.9, 3489.0], [83.0, 3496.0], [83.1, 3502.0], [83.2, 3510.0], [83.3, 3518.0], [83.4, 3521.0], [83.5, 3523.0], [83.6, 3531.0], [83.7, 3546.0], [83.8, 3550.0], [83.9, 3556.0], [84.0, 3559.0], [84.1, 3562.0], [84.2, 3582.0], [84.3, 3598.0], [84.4, 3617.0], [84.5, 3622.0], [84.6, 3626.0], [84.7, 3633.0], [84.8, 3637.0], [84.9, 3643.0], [85.0, 3650.0], [85.1, 3656.0], [85.2, 3659.0], [85.3, 3664.0], [85.4, 3673.0], [85.5, 3677.0], [85.6, 3681.0], [85.7, 3685.0], [85.8, 3693.0], [85.9, 3695.0], [86.0, 3701.0], [86.1, 3709.0], [86.2, 3723.0], [86.3, 3729.0], [86.4, 3732.0], [86.5, 3741.0], [86.6, 3747.0], [86.7, 3751.0], [86.8, 3755.0], [86.9, 3758.0], [87.0, 3765.0], [87.1, 3772.0], [87.2, 3776.0], [87.3, 3788.0], [87.4, 3795.0], [87.5, 3810.0], [87.6, 3822.0], [87.7, 3838.0], [87.8, 3840.0], [87.9, 3844.0], [88.0, 3848.0], [88.1, 3862.0], [88.2, 3865.0], [88.3, 3881.0], [88.4, 3885.0], [88.5, 3892.0], [88.6, 3912.0], [88.7, 3920.0], [88.8, 3928.0], [88.9, 3937.0], [89.0, 3942.0], [89.1, 3947.0], [89.2, 3950.0], [89.3, 3954.0], [89.4, 3970.0], [89.5, 3990.0], [89.6, 4011.0], [89.7, 4028.0], [89.8, 4029.0], [89.9, 4051.0], [90.0, 4060.0], [90.1, 4070.0], [90.2, 4089.0], [90.3, 4101.0], [90.4, 4109.0], [90.5, 4112.0], [90.6, 4116.0], [90.7, 4131.0], [90.8, 4150.0], [90.9, 4164.0], [91.0, 4166.0], [91.1, 4183.0], [91.2, 4198.0], [91.3, 4203.0], [91.4, 4209.0], [91.5, 4227.0], [91.6, 4229.0], [91.7, 4235.0], [91.8, 4249.0], [91.9, 4265.0], [92.0, 4285.0], [92.1, 4288.0], [92.2, 4305.0], [92.3, 4313.0], [92.4, 4325.0], [92.5, 4356.0], [92.6, 4367.0], [92.7, 4386.0], [92.8, 4399.0], [92.9, 4410.0], [93.0, 4443.0], [93.1, 4464.0], [93.2, 4495.0], [93.3, 4516.0], [93.4, 4532.0], [93.5, 4541.0], [93.6, 4548.0], [93.7, 4562.0], [93.8, 4567.0], [93.9, 4576.0], [94.0, 4579.0], [94.1, 4586.0], [94.2, 4596.0], [94.3, 4653.0], [94.4, 4668.0], [94.5, 4669.0], [94.6, 4689.0], [94.7, 4740.0], [94.8, 4782.0], [94.9, 4786.0], [95.0, 4808.0], [95.1, 4844.0], [95.2, 4849.0], [95.3, 4891.0], [95.4, 4957.0], [95.5, 4988.0], [95.6, 5067.0], [95.7, 5078.0], [95.8, 5129.0], [95.9, 5188.0], [96.0, 5198.0], [96.1, 5221.0], [96.2, 5279.0], [96.3, 5293.0], [96.4, 5309.0], [96.5, 5321.0], [96.6, 5365.0], [96.7, 5422.0], [96.8, 5455.0], [96.9, 5540.0], [97.0, 5554.0], [97.1, 5827.0], [97.2, 5874.0], [97.3, 5909.0], [97.4, 6277.0], [97.5, 6377.0], [97.6, 6509.0], [97.7, 6592.0], [97.8, 6752.0], [97.9, 6817.0], [98.0, 7294.0], [98.1, 7438.0], [98.2, 7599.0], [98.3, 8100.0], [98.4, 8537.0], [98.5, 10008.0], [98.6, 10791.0], [98.7, 14027.0], [98.8, 14556.0], [98.9, 15672.0], [99.0, 21164.0], [99.1, 22250.0], [99.2, 22792.0], [99.3, 30388.0], [99.4, 31317.0], [99.5, 33101.0], [99.6, 34004.0], [99.7, 34838.0], [99.8, 35010.0], [99.9, 35531.0]], "isOverall": false, "label": "Escenario 2", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 900.0, "maxY": 191.0, "series": [{"data": [[900.0, 28.0], [1000.0, 190.0], [1100.0, 191.0], [1200.0, 154.0], [1300.0, 188.0], [1400.0, 151.0], [1500.0, 142.0], [1600.0, 110.0], [1700.0, 74.0], [1800.0, 105.0], [1900.0, 74.0], [2000.0, 69.0], [2100.0, 63.0], [2300.0, 45.0], [2200.0, 63.0], [2400.0, 43.0], [2500.0, 47.0], [2600.0, 35.0], [2700.0, 31.0], [2800.0, 24.0], [2900.0, 28.0], [3000.0, 29.0], [3100.0, 18.0], [3300.0, 23.0], [3200.0, 20.0], [3400.0, 34.0], [3500.0, 31.0], [3700.0, 36.0], [3600.0, 39.0], [3800.0, 26.0], [3900.0, 24.0], [4000.0, 17.0], [4100.0, 23.0], [4200.0, 22.0], [4300.0, 17.0], [4500.0, 25.0], [4400.0, 8.0], [4600.0, 10.0], [4700.0, 7.0], [4800.0, 8.0], [5000.0, 6.0], [5100.0, 7.0], [4900.0, 5.0], [5200.0, 6.0], [5300.0, 9.0], [5500.0, 5.0], [5400.0, 3.0], [5800.0, 5.0], [5700.0, 1.0], [5900.0, 2.0], [6100.0, 1.0], [6200.0, 1.0], [6300.0, 3.0], [6600.0, 1.0], [6500.0, 4.0], [6800.0, 1.0], [6700.0, 2.0], [7100.0, 1.0], [7200.0, 2.0], [7400.0, 3.0], [7500.0, 2.0], [7600.0, 1.0], [8100.0, 2.0], [8500.0, 1.0], [8700.0, 1.0], [8600.0, 1.0], [10100.0, 1.0], [10000.0, 1.0], [10700.0, 1.0], [11100.0, 1.0], [13500.0, 1.0], [14000.0, 1.0], [14200.0, 1.0], [14500.0, 1.0], [15600.0, 1.0], [15400.0, 1.0], [16700.0, 1.0], [16800.0, 1.0], [21100.0, 1.0], [22200.0, 2.0], [21700.0, 1.0], [22700.0, 1.0], [23300.0, 1.0], [30300.0, 1.0], [30000.0, 1.0], [31200.0, 1.0], [31300.0, 2.0], [32300.0, 1.0], [33100.0, 1.0], [34800.0, 1.0], [34000.0, 2.0], [33800.0, 1.0], [35000.0, 2.0], [35500.0, 3.0], [35400.0, 1.0], [34900.0, 1.0]], "isOverall": false, "label": "Escenario 2", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 35500.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 4.0, "minX": 1.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 1476.0, "series": [{"data": [], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 904.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 1476.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [[3.0, 4.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 9.840425531914894, "minX": 1.68428658E12, "maxY": 10.0, "series": [{"data": [[1.684287E12, 10.0], [1.6842867E12, 10.0], [1.68428718E12, 9.840425531914894], [1.68428664E12, 10.0], [1.68428712E12, 10.0], [1.68428682E12, 10.0], [1.68428676E12, 10.0], [1.68428694E12, 10.0], [1.68428688E12, 10.0], [1.68428658E12, 10.0], [1.68428706E12, 10.0]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.68428718E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 1062.0, "minX": 1.0, "maxY": 4164.0, "series": [{"data": [[8.0, 4164.0], [4.0, 4045.0], [2.0, 1626.0], [1.0, 1932.0], [9.0, 1429.0], [10.0, 2519.1136842105184], [5.0, 1291.0], [6.0, 1136.0], [3.0, 1555.0], [7.0, 1062.0]], "isOverall": false, "label": "Escenario 2", "isController": false}, {"data": [[9.981124161073824, 2517.2546140939517]], "isOverall": false, "label": "Escenario 2-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 10.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 4.516666666666667, "minX": 1.68428658E12, "maxY": 7.74818327E7, "series": [{"data": [[1.684287E12, 850.1666666666666], [1.6842867E12, 1028.8833333333334], [1.68428718E12, 1255.9666666666667], [1.68428664E12, 899.8333333333334], [1.68428712E12, 1229.6], [1.68428682E12, 948.0666666666667], [1.68428676E12, 890.9333333333333], [1.68428694E12, 1193.0833333333333], [1.68428688E12, 1139.6833333333334], [1.68428658E12, 4.516666666666667], [1.68428706E12, 1176.2]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.684287E12, 5.247882985E7], [1.6842867E12, 6.346916585E7], [1.68428718E12, 7.74818327E7], [1.68428664E12, 5.55011742E7], [1.68428712E12, 7.583328401666667E7], [1.68428682E12, 5.852351421666667E7], [1.68428676E12, 5.4951657E7], [1.68428694E12, 7.36352193E7], [1.68428688E12, 7.033811135E7], [1.68428658E12, 274758.6], [1.68428706E12, 7.253618281666666E7]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.68428718E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 1957.0815602836878, "minX": 1.68428658E12, "maxY": 4782.0, "series": [{"data": [[1.684287E12, 3139.1727748691087], [1.6842867E12, 2610.9653679653675], [1.68428718E12, 1957.0815602836878], [1.68428664E12, 3156.029702970297], [1.68428712E12, 2189.786231884059], [1.68428682E12, 3195.95305164319], [1.68428676E12, 2325.215000000001], [1.68428694E12, 2246.507462686568], [1.68428688E12, 2549.5585937499986], [1.68428658E12, 4782.0], [1.68428706E12, 2270.1136363636365]], "isOverall": false, "label": "Escenario 2", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.68428718E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 1957.0531914893618, "minX": 1.68428658E12, "maxY": 4778.0, "series": [{"data": [[1.684287E12, 3139.162303664924], [1.6842867E12, 2610.909090909093], [1.68428718E12, 1957.0531914893618], [1.68428664E12, 3155.9653465346555], [1.68428712E12, 2189.760869565219], [1.68428682E12, 3195.910798122064], [1.68428676E12, 2325.1600000000026], [1.68428694E12, 2246.492537313433], [1.68428688E12, 2549.5351562500005], [1.68428658E12, 4778.0], [1.68428706E12, 2270.083333333333]], "isOverall": false, "label": "Escenario 2", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.68428718E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 0.3484848484848483, "minX": 1.68428658E12, "maxY": 1596.0, "series": [{"data": [[1.684287E12, 0.6544502617801047], [1.6842867E12, 0.6969696969696973], [1.68428718E12, 0.4609929078014182], [1.68428664E12, 72.98019801980195], [1.68428712E12, 0.37681159420289895], [1.68428682E12, 0.525821596244132], [1.68428676E12, 0.6450000000000005], [1.68428694E12, 0.6305970149253733], [1.68428688E12, 0.4882812500000004], [1.68428658E12, 1596.0], [1.68428706E12, 0.3484848484848483]], "isOverall": false, "label": "Escenario 2", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.68428718E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 926.0, "minX": 1.68428658E12, "maxY": 35550.0, "series": [{"data": [[1.684287E12, 35550.0], [1.6842867E12, 6592.0], [1.68428718E12, 23381.0], [1.68428664E12, 16866.0], [1.68428712E12, 10197.0], [1.68428682E12, 35533.0], [1.68428676E12, 6522.0], [1.68428694E12, 31317.0], [1.68428688E12, 34838.0], [1.68428658E12, 4782.0], [1.68428706E12, 8119.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.684287E12, 4527.900000000001], [1.6842867E12, 4785.2], [1.68428718E12, 2337.0000000000005], [1.68428664E12, 5149.700000000003], [1.68428712E12, 4034.9], [1.68428682E12, 3984.0000000000005], [1.68428676E12, 3916.400000000001], [1.68428694E12, 3228.8000000000015], [1.68428688E12, 3555.0], [1.68428658E12, 4782.0], [1.68428706E12, 3785.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.684287E12, 35482.66], [1.6842867E12, 6231.160000000003], [1.68428718E12, 22359.570000000007], [1.68428664E12, 16741.91], [1.68428712E12, 8966.190000000024], [1.68428682E12, 35463.270000000004], [1.68428676E12, 6507.890000000001], [1.68428694E12, 30176.519999999997], [1.68428688E12, 33900.96], [1.68428658E12, 4782.0], [1.68428706E12, 6738.900000000023]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.684287E12, 5399.449999999999], [1.6842867E12, 5336.5999999999985], [1.68428718E12, 3157.399999999999], [1.68428664E12, 7416.4], [1.68428712E12, 4583.349999999998], [1.68428682E12, 6195.649999999995], [1.68428676E12, 4397.4], [1.68428694E12, 3792.2], [1.68428688E12, 3720.0], [1.68428658E12, 4782.0], [1.68428706E12, 4552.75]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.684287E12, 1026.0], [1.6842867E12, 927.0], [1.68428718E12, 944.0], [1.68428664E12, 1018.0], [1.68428712E12, 990.0], [1.68428682E12, 954.0], [1.68428676E12, 984.0], [1.68428694E12, 926.0], [1.68428688E12, 979.0], [1.68428658E12, 4782.0], [1.68428706E12, 982.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.684287E12, 1906.0], [1.6842867E12, 2181.0], [1.68428718E12, 1332.5], [1.68428664E12, 2689.5], [1.68428712E12, 1801.5], [1.68428682E12, 1789.5], [1.68428676E12, 2097.0], [1.68428694E12, 1450.0], [1.68428688E12, 1580.0], [1.68428658E12, 4782.0], [1.68428706E12, 1974.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.68428718E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 1435.5, "minX": 1.0, "maxY": 32662.5, "series": [{"data": [[1.0, 3005.0], [4.0, 1728.5], [2.0, 2061.0], [8.0, 1578.0], [9.0, 1439.0], [5.0, 1734.0], [10.0, 1435.5], [3.0, 1880.5], [6.0, 1653.0], [7.0, 1508.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[5.0, 32662.5], [3.0, 32383.0], [6.0, 31343.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 10.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 1435.5, "minX": 1.0, "maxY": 32662.5, "series": [{"data": [[1.0, 3005.0], [4.0, 1728.5], [2.0, 2060.5], [8.0, 1578.0], [9.0, 1439.0], [5.0, 1734.0], [10.0, 1435.5], [3.0, 1880.5], [6.0, 1653.0], [7.0, 1508.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[5.0, 32662.5], [3.0, 32383.0], [6.0, 31343.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 10.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 0.18333333333333332, "minX": 1.68428658E12, "maxY": 4.6, "series": [{"data": [[1.684287E12, 3.183333333333333], [1.6842867E12, 3.85], [1.68428718E12, 4.533333333333333], [1.68428664E12, 3.3666666666666667], [1.68428712E12, 4.6], [1.68428682E12, 3.55], [1.68428676E12, 3.3333333333333335], [1.68428694E12, 4.466666666666667], [1.68428688E12, 4.266666666666667], [1.68428658E12, 0.18333333333333332], [1.68428706E12, 4.4]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.68428718E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.68428658E12, "maxY": 4.7, "series": [{"data": [[1.684287E12, 3.1666666666666665], [1.6842867E12, 3.85], [1.68428718E12, 4.7], [1.68428664E12, 3.3666666666666667], [1.68428712E12, 4.6], [1.68428682E12, 3.533333333333333], [1.68428676E12, 3.3333333333333335], [1.68428694E12, 4.45], [1.68428688E12, 4.25], [1.68428658E12, 0.016666666666666666], [1.68428706E12, 4.4]], "isOverall": false, "label": "201", "isController": false}, {"data": [[1.684287E12, 0.016666666666666666], [1.68428682E12, 0.016666666666666666], [1.68428694E12, 0.016666666666666666], [1.68428688E12, 0.016666666666666666]], "isOverall": false, "label": "503", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.68428718E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.68428658E12, "maxY": 4.7, "series": [{"data": [[1.684287E12, 3.1666666666666665], [1.6842867E12, 3.85], [1.68428718E12, 4.7], [1.68428664E12, 3.3666666666666667], [1.68428712E12, 4.6], [1.68428682E12, 3.533333333333333], [1.68428676E12, 3.3333333333333335], [1.68428694E12, 4.45], [1.68428688E12, 4.25], [1.68428658E12, 0.016666666666666666], [1.68428706E12, 4.4]], "isOverall": false, "label": "Escenario 2-success", "isController": false}, {"data": [[1.684287E12, 0.016666666666666666], [1.68428682E12, 0.016666666666666666], [1.68428694E12, 0.016666666666666666], [1.68428688E12, 0.016666666666666666]], "isOverall": false, "label": "Escenario 2-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.68428718E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.68428658E12, "maxY": 4.7, "series": [{"data": [[1.684287E12, 3.1666666666666665], [1.6842867E12, 3.85], [1.68428718E12, 4.7], [1.68428664E12, 3.3666666666666667], [1.68428712E12, 4.6], [1.68428682E12, 3.533333333333333], [1.68428676E12, 3.3333333333333335], [1.68428694E12, 4.45], [1.68428688E12, 4.25], [1.68428658E12, 0.016666666666666666], [1.68428706E12, 4.4]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.684287E12, 0.016666666666666666], [1.68428682E12, 0.016666666666666666], [1.68428694E12, 0.016666666666666666], [1.68428688E12, 0.016666666666666666]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.68428718E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

